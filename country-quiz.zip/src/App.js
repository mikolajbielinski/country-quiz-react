import H1 from './components/H1';
import Main from './components/Main';

function App() {
  return (
    <Main>
      <H1>Country quiz</H1>
      <p>sdfngisdfbigudfsnigdfs</p>
      <p>sdfngisdfbigudfsnigdfs</p>
      <p>sdfngisdfbigudfsnigdfs</p>
      <p>sdfngisdfbigudfsnigdfs</p>
    </Main>
  );
}

export default App;
