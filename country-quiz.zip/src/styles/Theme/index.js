const Theme = {
  colors: {
    primary: '#6066D0B2',
    secondary: '#2F527B',
    primaryWhite: '#F2F2F2',
    hover: '#F9A826',
    rightAnswer: '#60BF88',
    wrongAnswer: '#EA8282',
  },
};

export default Theme;
