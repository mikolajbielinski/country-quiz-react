import styled from 'styled-components';

const Main = styled.main`
  position: relative;
  border-radius: 1rem;
  padding: 2rem 15rem;
  background-color: ${props => props.theme.colors.primaryWhite};
`;

export default Main;
